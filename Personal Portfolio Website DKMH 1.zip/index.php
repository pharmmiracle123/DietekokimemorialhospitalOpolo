<DOCTYPE html>
  <html>
    <head>
      <tile>
        Deito-Koki Memorial Hospital 
      </tile>
    </head>
    <body>
      <?php
      include("include/header.php");
     ?>
     
     <div class="container">
       <div class="col-md-12">
         <div class="row">
           <div class="col-md-3 mx-1 shadow">
             <img scr="#" style="width:#%" height:>
              <h5 class="text-center">Click on the button fir more information</h5>
             <a href="">
               <button class="btn btn-success my-3" style="margin left:30%;">More Information</button>
             </a>
           </div>
           <div class="col-md-4 mx-1 shadow">
             <img scr="#" width:#%;>
              <h5 class="text-center">Create an account so thaf we can take good care of you</h5>
             <a href="">
               <button class="btn btn-success my-3" style="margin left:30%;">Create Account</button>
             </a>
           </div>
           
           <div class="col-md-4 mx-1 shadow">
             <img scr="#" width:#%;>
             <h5 class="text-center">Doctors</h5>
             <a href="">
               <button class="btn btn-success my-3" style="margin left:30%;">View List of Doctors</button>
             </a>
           </div>
         </div>
       </div>
     </div>
    </body>
  </html>