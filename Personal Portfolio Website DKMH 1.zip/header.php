<DOCTYPE html>
<html>
  <head>
    <title>DKMH</title>
    <link rel= "stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootsrap/4.5.0/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
  </head>
  <body>
  <nav class="navbar navbar-expand-lg navbar-info bg-info">
    <h5 class="text-white">Deite-koki Memorial Hospital</h5>
    <div class="mr-auto">
    
    </div>
    <ul class="navbar-nav">
      <li class="nav-items">
        <a href="" class="nav-link">Admin</a>
      </li>
      <li class="nav-items">
        <a heref="" class="nav-link">Doctors</a>
      </li>
      <li class="nav-items">
        <a heref="" class="nav-link">Patients</a>
      </li>
    </ul>
  </nav>
  </body>
</html>